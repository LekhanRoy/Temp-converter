Temperature Converter
=====================

An Android app for converting temperature between Celsius, Fahrenheit, and Kelvin.

To Use
------

1. Clone this project into your Eclipse environment.
2. Open the "Tasks" view (Window -> Show View -> Tasks).
3. Complete the TODO items.

Features
--------

* MVC
* Update / React Strategy
* Double Seekbar: allows for negative numbers